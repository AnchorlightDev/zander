# Changelog

## Unreleased

### Changed

- **`/forcelink` and `/lp-audit` permissions** (`zander.discord.forcelink`, `zander.discord.lpaudit`) can now be ticked in the ranks dashboard.
- **The unused `internal` API scope has been removed** from the API Keys page. No route ever required it; existing keys that have it are unaffected.
- **Removed unused variables from `.env.example`:** `STRIPE_PRICE_MAP_TOKEN_*`, `STRIPE_PRICE_SUPPORTER_MONTHLY` and `MINEMONITOR_DATE_FORMAT`.

### Documentation

- **All documentation now lives at [anchorlight.dev/docs/products/zander](https://anchorlight.dev/docs/products/zander).** The guides that were in `docs/`, `SETUP.md` and the plugin READMEs have moved there and been brought up to date for 2.2.0. The README, `SETUP.md` and the plugin READMEs now point to the site.
- **Dashboard "Documentation" links** go to the matching pages on the docs site. Several pointed at old page names that no longer existed.
- **The permission reference is generated from the registry.** `node scripts/permissionsTable.mjs` prints the tables for the docs site's permissions page, so the published list matches the ranks dashboard checklist.

### Security

- **Open redirect after login closed.** A `returnTo` or `redirect` value with a tab or line break after the first slash (`/%09/evil.example`) passed the same-site check, but browsers strip those characters and followed it to another site. Control characters are now refused, and redirect targets are rebuilt from the parsed path rather than passed through. Affects login, Discord login, password reset, profile account linking, notifications and support category settings.
- **Email validation can no longer be made slow.** The email pattern used by the site settings, admin user and public page forms backtracked quadratically on long crafted input; it is now linear. Slug, CSV filename and URL tidy-ups no longer use end-anchored regexes on user input for the same reason.
- **Event banners only get the Cloudinary transform on Cloudinary's own host**, not any URL that merely contains `res.cloudinary.com`.
- **Rate limit on profile saves** (display, personal, interests, about, social): 30 a minute per address.

### Fixed

- **Discord event text and budget labels decode entities once.** `&amp;lt;` became `<` instead of `&lt;`.
- **Event descriptions are stripped of tags completely** in page descriptions and the review queue; a single pass could leave a nested tag behind (the text was still escaped on output).
- **Dashboard image previews** only show `https://` or same-site images, and the finance icon preview no longer builds HTML from a string.
- **Error logs keep their arguments in order** when an event ID, ticket number or URL contains `%`.
- **Faster page loads, especially when logged in.** Stylesheets, scripts and images no longer each run a notifications query (about 25 per logged-in page view), and the burst of requests a page makes now shares one session lookup instead of one each.
- **The homepage is about 2 seconds faster.** Its community counters were fetched from the site's own public address on every visit with no time limit; they are now read in-process, kept for 5 minutes, and never hold the page for more than 1.5 seconds.
- **Blank white pages are now logged.** An HTML page sent with an empty or near-empty body, or an "already sent" error on anything but a HEAD request, is written to the log with its address so the cause can be found. Both were previously silent.
- **`/connect <server>` works in the hub.** It was declared but had no command behind it. It now asks the proxy to move you, with the same checks as the navigation compass (`serverpermissions.server.<id>`, unknown servers, rate limit).
- **zander-hub permission names match the code.** `plugin.yml` declared `zander.fly` and `zanderhub.build`, but the plugin checks `zander.hub.fly` and `zander.hub.build`; the declarations now use the real names. `zanderhub.portal.admin` now grants every `/zportal` permission and `zanderhub.administrator` grants every hub permission (both previously did nothing).
- **The Finance module switch works.** Switching it off now hides the public Finance Centre and reports, the finance dashboard and `/api/finance`, and drops `/finance` from the sitemap. It was previously only cosmetic.
- **The Punishment commands switch works.** Switching it off now disables `/punish` and the public `/punishments` page; before, it only hid a menu link.
- **"Require punishment DM to succeed" works.** When it is on and the user can't be sent a DM (for example, they have DMs closed), the punishment is not applied and staff are told why. The setting previously did nothing.
- **Live-stream announcements use your site's address** instead of a hard-coded `craftingforchrist.net/watch`.
- **`.env.example` no longer sets `TRUST_PROXY_HOPS=1`.** On Render that value stops the session cookie being set and breaks every login; leave the variable unset. `SETUP.md` and the 2.2.0 upgrade notes said to set it and have been corrected.

## 2.2.0

### Upgrading from 2.1.0

Read these before deploying.

- **`sessionCookieSecret` must be a real secret.** The app now refuses to start if it is shorter than 32 characters or still the example value. Generate one with `openssl rand -hex 32`.
- **Leave `TRUST_PROXY_HOPS` unset** on an https deployment such as Render. The app then trusts the platform proxy, so the Secure session cookie is issued and rate limiting sees each visitor's real IP. **Do not copy `TRUST_PROXY_HOPS=1` from an older `.env.example`:** a numeric hop count can make the app see requests as plain http, which stops the session cookie being set and breaks every login. Only set an exact number if your proxy chain is fixed and the boot log shows `protocol=https`.
- **New environment variables for Compass SSO** (only needed if you run Compass): `OIDC_ISSUER`, `OIDC_JWKS` (generate with `node scripts/generate-oidc-jwks.mjs`), `OIDC_COMPASS_CLIENT_ID`, `OIDC_COMPASS_CLIENT_SECRET`, `OIDC_COMPASS_REDIRECT_URIS` and `OIDC_COMPASS_POST_LOGOUT_URIS`. See `.env.example`.
- **Two new API key scopes.** Give each game server's key the `hologram` scope (or set a dedicated `holograms.api-key` in the addon's `config.yml`) before installing the new `zander-addon`, and keep `bridge` on keys used by the addon's bridge features. The `compass` scope is for the Compass bot only. Keys can't be edited, so to add a scope create a new key at **Dashboard → API Keys**, put it in the server's config, then revoke the old one.
- **New permission nodes:** `zander.web.pages`, `zander.web.menus`, `zander.web.resources`, `zander.web.resources.review`, `zander.web.holograms` and `zander.web.tickets.manage`. Ticket category management now needs `zander.web.tickets.manage`; holders of the old view node lose rename/delete until it is granted.
- **Email error alerts are gone.** `adminErrorEmail` and its ignore list no longer do anything and can be removed from your environment; use Sentry for error reporting.
- **The Discord staff audit log webhook setting has been removed.**
- **The legacy `migration/*.sql` files and `dbinit.sql` are gone.** Prisma migrations are now the only way to create or upgrade the database.
- **10 database migrations** (`0067`–`0076`) run on deploy via `npm run build`. They add tables and columns, and make support tickets' `userId` nullable for guest tickets; nothing is dropped.
- **Node.js 22** is pinned in `.node-version`; the app no longer starts with experimental Node flags (`Procfile` is now `node app.js`).
- **New modules start switched off:** Resources and the Contact form are off by default; turn them on at **Dashboard → Modules**. Holograms are on by default.
- **Plugins:** update `zander-addon` on every game server for holograms.

### New

- **Custom pages** — create, edit and publish your own site pages from the dashboard (`zander.web.pages`).
- **Menu editor** — edit the top bar, header and footer navigation menus (`zander.web.menus`).
- **Resources** — a public resources page with category tabs where members can suggest resources. Staff with `zander.web.resources.review` vote on suggestions within a configurable window, and `zander.web.resources` can decide overdue ones or override the result.
- **Contact form and guest tickets** — people without an account can open a support ticket from the contact form and follow the conversation through a private emailed link.
- **Support dashboard overview** — ticket queue and statistics at a glance for staff.
- **Holograms** — design text holograms in the dashboard (`zander.web.holograms`), grouped and with optional countdowns and expiry times, then place them in-game with `/hologram create <name> <group>`. Servers poll for changes, so edits appear without a restart.
- **Live stream announcements in-game** — when a creator goes live, an in-game tip announces it, and it is removed as soon as the stream ends.
- **Compass SSO** — Zander is now an OpenID Connect provider, so the Compass staff portal signs staff in with their CFC account. Only members of the configured staff ranks can sign in. Compass also gets read-only lookups for groups (with display names), members (with avatars) and Discord identities.
- **Report Message** — right-click a Discord message → Apps → Report Message to report it to staff.
- **Edit scheduled Discord embeds** after creating them; rich-text descriptions are converted to Discord formatting.

### Improved

- **Shop directory** now finds and labels enchanted books, enchanted gear, potions, firework rockets and shulker box contents for shops created since the QuickShop-Hikari item format change. Search for an enchantment such as `sharpness` or `fire protection` and the result shows e.g. "Enchanted Book (Sharpness V)".
- **Account pages** — redesigned registration, email verification, password reset and Minecraft linking pages, with clearer code entry and password rules.
- **Punishment settings** apply as soon as they are saved, without a restart.
- **Discord crons** share one throttled member fetch, so booster rewards, rank role sync, unverified-member reminders and the LuckPerms audit no longer hit Discord's rate limits by running at the same time.

### Security
- Public registration can no longer overwrite the credentials of an existing account that is Discord-linked, verified or registered; it only claims bare profile rows or an unfinished local registration.
- Staff recovery actions (change email, trigger password reset) refuse accounts that hold permissions the actor lacks, a staff-set email is unverified until confirmed, and resets require a verified address.
- Discord login carries an OAuth `state` parameter; the `discordId` cookie used during account linking is signed and the link code endpoint is throttled and reads the id from that cookie, not the form.
- Dashboard proxies (badges, bridge) only forward integer ids, closing a path traversal that reached other internal API endpoints with the internal key.
- Ticket category management moved behind the new `zander.web.tickets.manage` node; the view node no longer lets anyone rename or cascade-delete categories.
- Cookie-authenticated writes are rejected when the browser reports a cross-site origin (Sec-Fetch-Site / Origin), on both site routes and session-authenticated API routes.
- Rate limiting and audit IPs use `req.ip` from Fastify's proxy handling (trusting the platform proxy on https, or an explicit `TRUST_PROXY_HOPS`) instead of the client-controlled first X-Forwarded-For entry; emailed codes are invalidated after five wrong guesses; forgot-password, Minecraft code entry and ticket creation are throttled.
- Password resets invalidate the account's other sessions. The app refuses to start with the example session secret.
- Uploads: 8 MB limit actually enforced (was 1 MiB with a 500), folder restricted by permission, magic-byte and Cloudinary format checks, rate limited; duplicate dashboard handler removed.
- Web push subscriptions must point at a known push service (blind SSRF). Profile social fields are validated (Reddit must be an https reddit.com URL). Vault descriptions are sanitised; announcement, application, vault and event links must be http(s)/mailto/site paths.
- Rich-text sanitiser no longer allows arbitrary `class` values, protocol-relative URLs or unbounded nesting. `/api` 5xx responses no longer echo internal error text. Sentry no longer receives request bodies or cookies.
- LuckPerms rank slugs are validated before use in LIKE patterns; QuickShop and user searches escape LIKE wildcards. `multipleStatements` is off on the main pool.
- Privileged slash commands are guild-only. Rank-permission holders cannot grant nodes to a rank they hold. Placeholder user rows no longer shadow real players in username lookups, nickname enforcement or the birthday rank grant (which now addresses players by UUID).
- Dependencies: all 8 `npm audit` advisories cleared (2 high), including XSS bypasses in `sanitize-html` and denial-of-service issues in `undici` and `nodemailer`. The lockfile was checked against known 2026 npm supply-chain compromises.

### Fixed
- Rank/Discord role sync no longer strips a rank's role from every member when that one rank's lookup fails, and runs are serialised.
- Expired Discord bans/mutes stay active and retry when the Discord call fails instead of being marked expired; `/punish unban` keeps the record if Discord refused.
- Finance month ranges include the last day of the month; a paid webstore order whose item cannot be resolved is marked `failed`, not `fulfilled`; Stripe catalogue fetches are cached for a minute with a timeout.
- Audit timestamp updates no longer throw `ReferenceError` on DB errors; Prisma write-timeout timers are cleared; webhook clients in message listeners are destroyed; Twitch/YouTube crons do not mark every stream offline during an API outage.
- Unverified users can request a new email verification code (resend button, and a fresh code on login) instead of having to re-register.
- Indexes added for sessions, notifications, game sessions, scheduled messages and code tables; the support-message charset conversion is a real migration instead of a boot-time `ALTER`.
- Maintenance scripts under `scripts/` default to dry-run and require `--apply`. Removed the `crypto`, `path` and `querystring` npm packages that shadow Node built-ins; `package-lock.json` is no longer gitignored.
- The addon's command bridge no longer gets 404s from the website: the missing API route was added.
- The verify button on code-entry pages (email verification, password reset) could stay unresponsive because the script looked it up before it existed.
- `zander.web.holograms` was checked by the hologram dashboard but missing from the permission registry, so it couldn't be granted from the ranks permission checklist. It now appears there.

### Documentation

- **New README** — a project overview with a feature tour, architecture diagram, quick start and documentation index.
- **Reference docs moved to `docs/`** — the permission reference, API keys, webstore, creator content, forms and booster rewards guides now live in [`docs/`](docs/). The permission reference is [`docs/permissions.md`](docs/permissions.md).

### Removed

- **Email error alerts** (`adminErrorEmail`) — Sentry covers error reporting.
- **Discord staff audit log webhook** setting.
- **Legacy SQL migration files** (`migration/`) and `dbinit.sql`, replaced by Prisma migrations.
- **Experimental Node flags** from `Procfile` and the npm scripts.

## 2.1.0

### Upgrading from 2.0.0

Read these before deploying.

- **The shared `apiKey` is gone.** Every caller of the API — each Minecraft server, the uptime monitor, and this app itself — now needs its own client key. Create them at **Dashboard → API Keys** (`zander.web.apikeys`); keys look like `zdr_<prefix>_<secret>`. A request carrying the old shared key is rejected with 401.
- **New environment variables:**
  - `INTERNAL_API_KEY` (**required**) — this app's own client key, used for its calls to its own API. Create a client for it at Dashboard → API Keys.
  - `MINEMONITOR_BASE_URL`, `MINEMONITOR_CONNECTION_TOKEN` — see the content filtering note below, and `.env.example`.
- **Content filtering has moved to MineMonitor.** The local `filter.json` word and link lists are gone; the link and phrase filters now ask MineMonitor, which filters through Purify. **If MineMonitor is not configured, or does not answer, content is let through unfiltered.** Set the two `MINEMONITOR_*` variables (or the base URL at Dashboard → Settings → Automation) before deploying if you rely on the filter.
- **Site settings and module switches now live in the database.** `config.json` and `features.json` are no longer read at runtime. On the first boot that finds them, they are imported once into the database. After that, edit settings at **Dashboard → Settings** and switch modules on and off at **Dashboard → Modules**. You can then delete the files.
- **25 database migrations** (`0041`–`0066`) run on deploy via `npm run build`. Migration `0066` cancels leftover duplicate event announcements (see Fixed); nothing is deleted.
- **Node.js 20 or newer** is required.
- **Plugins:** built for Java 21. The Waterfall proxy plugin has been removed; use Velocity.

### New

- **Forms** — build application and survey forms with section breaks, field requirements, eligibility rules, drafts, reapply cooldowns, access codes and optional review. Submissions can open a support ticket or post to a Discord forum thread or DM, and can be exported to CSV. Forms can be duplicated.
- **Webstore** — product and category management, with per-item visibility and settings.
- **Site settings and Modules dashboards** — edit site configuration and turn features on or off without touching files.
- **API Keys dashboard** — issue, scope and revoke a separate key for each API client.
- **Default event announcements** — set Discord, MOTD, in-game tip and website announcements once (Events → Templates → Default Announcements). New events and templates start with them, and **Apply to Existing Events** adds them to upcoming events that don't have them yet.
- **Rank-locked events** — limit an event to certain ranks, with a teaser description shown to everyone else.
- **Discord booster rewards** — give ranks to members who boost the Discord server, and remove them when the boost ends.
- **Rank permissions management** in the dashboard, plus self-promotion rules for rank assignment.
- **Bedrock Edition** landing page and connection details.
- **User profiles** — timezone and birthday.
- **Region settings** — the site's region, country and language, used across the site.
- **Dismissible site-wide banner**; announcements now record when they were created.
- **Verification reminders** for unverified Discord members.
- **Content filtering through MineMonitor** (backed by Purify), including Discord invite-link handling.
- **Latest forum posts on the homepage** — the newest discussions visitors can see, with an excerpt. Show one category (for example network announcements) or all of them, and set how many, at Dashboard → Settings → Watch, Events & Forums.
- **Version and commit** shown in the site and dashboard footers.

### Improved

- **Event announcements move with the event.** Changing an event's date or time reschedules its announcements, on drafts too, and the event page shows when each one will go out.
- **Event templates** pre-fill the new-event form, and the editors give clearer errors.
- **Discord timestamps** in event descriptions render on the site the same way they do in Discord.
- **Locked forum categories** explain what's needed to get access.
- **Event banners** keep their natural aspect ratio on every screen size.
- **Discord role sync** reports what it did and why it failed, and matches users by LuckPerms UUID first, so placeholder accounts no longer get the wrong roles.
- **Discord account linking** resolves conflicts and merges accounts instead of blocking.
- **Sessions** are cached in memory, so most requests no longer read the session from the database.
- **Finance budgets** — entries can be removed from a given month onwards.

### Fixed

- **Event announcements:**
  - Draft events could post their announcements to Discord.
  - Cancelled and deleted events kept announcing: queued Discord messages still went out and MOTDs and banners stayed up.
  - Saving a published event duplicated its announcements.
  - Announcement tokens such as `{discord_f}` and `{endAt}` were posted as raw text.
  - A 0-minute "before event" announcement never sent.
  - Announcements due while the bot was offline were marked failed instead of being retried.
  - Duplicating an event lost its announcements.
  - Editors without reviewer rights could change the announcements of approved and published events.
- **Long report reasons** are trimmed to fit instead of failing to save.
- **Auth utility pages** (password reset and similar) are kept out of search engines.

### Security

- **Content Security Policy**, in report-only mode, with a reporting endpoint.
- **Event descriptions** are sanitised against XSS.
- **Verification and reset codes** are generated with a cryptographic random source.
- **Webhook events** are claimed atomically, so a replayed Stripe event can't be processed twice.
- **Webstore commands** are escaped before being sent to a server.
- **Dependencies** — all known high-severity advisories resolved (`npm audit` is clean).

### Removed

- **Unused files:** about 15 MB of assets (an old admin theme and its fonts and scripts), dead views, and five unused npm packages.
- **`nodemon`** — `npm run dev` now uses Node's built-in `--watch`.
- **The Waterfall plugin.**
