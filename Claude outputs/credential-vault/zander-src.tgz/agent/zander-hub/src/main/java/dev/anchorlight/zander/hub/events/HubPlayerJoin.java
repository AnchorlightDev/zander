package dev.anchorlight.zander.hub.events;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import dev.anchorlight.zander.hub.ConfigurationManager;
import dev.anchorlight.zander.hub.items.NavigationCompassItem;
import dev.anchorlight.zander.hub.utils.Misc;
import dev.anchorlight.zander.hub.utils.WelcomeSounds;

public class HubPlayerJoin implements Listener {
    // misc settings
    private static final long ROUTINE_PLAYER_JOINED_DELAY = (long) (1.2f * 20); // ticks

    // sound settings
    private static final float SOUND_PITCH = 1.0f;
    private static final float SOUND_VOLUME = 1.0f;

    // firework settings
    private static final double FIREWORK_GROUND_HEIGHT = 3; // blocks
    private static final long FIREWORK_DETONATE_DELAY = (long) (0.3f * 20); // ticks
    private static final Color[] FIREWORK_COLOR_PALETTE = {
            Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.PURPLE,
            Color.ORANGE, Color.WHITE, Color.AQUA, Color.LIME,
    };

    private final JavaPlugin plugin;

    public HubPlayerJoin(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    /// Triggers when player's client has joined the world.
    /// Good for initial player world interactions (gameplay state etc).
    /// Runs at LOW priority so the inventory clear happens before other
    /// plugins (e.g. zander-addon) give join items at NORMAL/HIGH priority.
    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        // Previously done from PlayerLoginEvent, which is deprecated since
        // 1.21.6 and whose replacements are all pre-login events with no
        // Player. Nothing here needs login timing — the player is not in the
        // world yet at that point anyway.
        setPermissions(player);
        setInitialState(player); // * just be aware, runs before checking vanish
        if (Misc.isVanish(player))
            return;
        event.joinMessage(ConfigurationManager.getMessages().getPlayerJoin(player.displayName()));
        Bukkit.getScheduler().runTaskLater(plugin, () -> scheduledLogin(player), ROUTINE_PLAYER_JOINED_DELAY);
    }

    /// Set special permission depending on the player.
    private void setPermissions(Player player) {
        if (player.hasPermission("zander.hub.fly")) {
            player.setAllowFlight(true);
        }
    }

    /// Set the initial state of the player in the world.
    private void setInitialState(Player player) {
        int compassSlot = ConfigurationManager.getMisc().getSlotHubCompass();
        setupNoCollision(player);
        player.teleport(ConfigurationManager.getHubLocations().getSpawn());
        player.getInventory().clear();
        player.getInventory().setHeldItemSlot(compassSlot);
        player.getInventory().setItem(compassSlot, NavigationCompassItem.createCompass());
        resetVitals(player);
    }

    /// Reset the player's survival state on arrival in the hub.
    ///
    /// HubProtection cancels FoodLevelChangeEvent, which stops hunger draining
    /// but equally stops it ever refilling, and nothing here previously set it.
    /// A player therefore kept whatever food level their hub playerdata last
    /// stored, permanently — arriving hungry meant staying hungry forever.
    /// The same applied to health, since EntityDamageEvent is cancelled but
    /// nothing heals.
    ///
    /// setFoodLevel/setHealth are direct setters and do not fire the cancelled
    /// FoodLevelChangeEvent, so these take effect.
    private void resetVitals(Player player) {
        player.setFoodLevel(20);
        player.setSaturation(20.0f);
        player.setExhaustion(0.0f);

        AttributeInstance maxHealth = player.getAttribute(Attribute.MAX_HEALTH);
        player.setHealth(maxHealth != null ? maxHealth.getValue() : 20.0);

        // Carried over from wherever the player came from; damage is cancelled
        // in the hub so these would otherwise persist as a cosmetic artefact.
        player.setFireTicks(0);
        player.setRemainingAir(player.getMaximumAir());
    }

    /// Delayed login triggers (logic that's not immediate on login).
    private void scheduledLogin(Player player) {
        if (!player.isConnected())
            return;
        // * bukkit determines by reading 'world/playerdata'
        if (!player.hasPlayedBefore() || ConfigurationManager.getMisc().getAlwaysFirstJoin()) {
            chatWelcomeMessageFirst(player);
            spawnWelcomeFirework(player);
        } else {
            chatWelcomeMessageNormal(player);
        }
        playWelcomeSound(player);
    }

    /// Disable entity collision for player.
    /// Correct way as mentioned at:
    /// https://hub.spigotmc.org/javadocs/bukkit/org/bukkit/entity/LivingEntity.html#setCollidable(boolean)
    private void setupNoCollision(Player player) {
        Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
        Team team = scoreboard.getTeam("nocollision");
        if (team == null) {
            team = scoreboard.registerNewTeam("nocollision");
            team.setOption(Team.Option.COLLISION_RULE, Team.OptionStatus.NEVER);
        }
        team.addEntry(player.getName());
    }

    /// Send a 'normal welcome' message in player's chat.
    private void chatWelcomeMessageNormal(Player player) {
        sendWelcomeLines(player, "welcome");
    }

    /// Send a 'new player welcome' message in player's chat.
    private void chatWelcomeMessageFirst(Player player) {
        sendWelcomeLines(player, "welcome_newplayer");
    }

    /// Send each configured line, translating the legacy '&' colour codes the
    /// welcome files use.  ChatColor.translateAlternateColorCodes is
    /// deprecated; LegacyComponentSerializer is the Adventure equivalent and
    /// reads exactly the same '&' syntax, so the config files are unchanged.
    private void sendWelcomeLines(Player player, String configKey) {
        List<String> message = ConfigurationManager.getWelcome().getStringList(configKey);
        for (String row : message) {
            player.sendMessage(LegacyComponentSerializer.legacyAmpersand().deserialize(row));
        }
    }

    /// Play a random sound for the player.
    private void playWelcomeSound(Player player) {
        Sound randomSound = WelcomeSounds.getRandomSound();
        player.playSound(player.getLocation(), randomSound, SOUND_VOLUME, SOUND_PITCH);
    }

    /// Spawn a pretty firework where the player is.
    private void spawnWelcomeFirework(Player player) {
        Location spawnLoc = player.getLocation().add(0, FIREWORK_GROUND_HEIGHT, 0);
        Firework firework = player.getWorld().spawn(spawnLoc, Firework.class);
        FireworkMeta meta = firework.getFireworkMeta();

        Random random = new Random();
        Color[] FCP = FIREWORK_COLOR_PALETTE;

        // random primary-colors
        List<Color> colors = new ArrayList<>();
        int numColors = random.nextInt(3) + 2; // 2-4 colors
        for (int i = 0; i < numColors; i++) {
            colors.add(FCP[random.nextInt(FCP.length)]);
        }

        // random fade-color and firework type
        Color fadeColor = FCP[random.nextInt(FCP.length)];
        FireworkEffect.Type[] types = FireworkEffect.Type.values();
        FireworkEffect.Type type = types[random.nextInt(types.length)];

        FireworkEffect effect = FireworkEffect.builder()
                .flicker(false)
                .trail(true)
                .with(type)
                .withColor(colors)
                .withFade(fadeColor)
                .build();
        meta.addEffect(effect);
        meta.setPower(1);
        firework.setFireworkMeta(meta);

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (firework.isValid())
                firework.detonate();
        }, FIREWORK_DETONATE_DELAY);
    }
}
