import cron from "node-cron";
import { createRequire } from "module";
import { client } from "../controllers/discordController.js";
import {
  getExpiredActivePunishments,
  expirePunishment,
  getAllActivePunishments,
} from "../controllers/discordPunishmentController.js";

const require = createRequire(import.meta.url);
const config = require("../lib/config/config.cjs");

// Read at use time rather than copying at import: these settings live in the
// database and a dashboard change should take effect without a bot restart.
const getGuildId = () => config.discord?.guildId;
const getMutedRoleId = () => config.discord?.roles?.muted;

/**
 * Lift an expired punishment in Discord.
 *
 * Returns true when Discord now reflects the lifted state (either the call
 * succeeded or Discord reported it was already lifted), false when it could
 * not be applied. The row is only marked EXPIRED on true, so a Discord
 * outage or missing-permission error is retried on the next tick instead of
 * leaving someone banned or muted forever with no record of it.
 */
async function liftInDiscord(punishment) {
  const GUILD_ID = getGuildId();
  const MUTED_ROLE_ID = getMutedRoleId();
  if (!client?.isReady?.() || !GUILD_ID) return false;

  let guild;
  try {
    guild = await client.guilds.fetch(GUILD_ID);
  } catch (error) {
    console.error("punishmentExpiryCron: guild fetch failed", error);
    return false;
  }
  if (!guild) return false;

  if (punishment.type === "TEMP_BAN") {
    try {
      await guild.members.unban(
        punishment.target_discord_user_id,
        "[Auto] Temporary ban expired"
      );
    } catch (error) {
      // 10026 Unknown Ban: already unbanned, which is the state we want.
      if (error.code !== 10026) {
        console.warn("punishmentExpiryCron: failed to unban", punishment.id, error.message);
        return false;
      }
    }
  }

  if (punishment.type === "TEMP_MUTE" && MUTED_ROLE_ID) {
    try {
      const member = await guild.members.fetch(punishment.target_discord_user_id);
      if (member) {
        await member.roles.remove(MUTED_ROLE_ID, "[Auto] Temporary mute expired");
      }
    } catch (error) {
      // 10007 Unknown Member: they left; nothing to remove.
      if (error.code !== 10007) {
        console.warn("punishmentExpiryCron: failed to unmute", punishment.id, error.message);
        return false;
      }
    }
  }

  return true;
}

// Run every minute to check for expired punishments
const punishmentExpiryTask = cron.schedule("*/1 * * * *", async () => {
  if (!client?.isReady?.()) return;

  try {
    const expired = await getExpiredActivePunishments();

    for (const punishment of expired) {
      try {
        if (!(await liftInDiscord(punishment))) continue; // retry next tick
        await expirePunishment(punishment.id);
      } catch (error) {
        console.error(
          `punishmentExpiryCron: failed to expire punishment ${punishment.id}:`,
          error
        );
      }
    }
  } catch (error) {
    console.error("punishmentExpiryCron: query failed", error);
  }
});

punishmentExpiryTask.start();

/**
 * Startup reconciliation: ensure active punishments are enforced.
 * Called once when the bot becomes ready.
 */
export async function reconcileActivePunishments() {
  const GUILD_ID = getGuildId();
  const MUTED_ROLE_ID = getMutedRoleId();
  if (!client?.isReady?.() || !GUILD_ID) return;

  try {
    const guild = await client.guilds.fetch(GUILD_ID);
    if (!guild) return;

    const activePunishments = await getAllActivePunishments();

    // First expire any that should have expired while bot was down
    const now = new Date();
    for (const p of activePunishments) {
      if (p.expires_at && new Date(p.expires_at) <= now) {
        if (await liftInDiscord(p)) await expirePunishment(p.id);
        continue;
      }

      // For active mutes, make sure the muted role is applied
      if ((p.type === "TEMP_MUTE" || p.type === "PERM_MUTE") && MUTED_ROLE_ID) {
        try {
          const member = await guild.members.fetch(p.target_discord_user_id);
          if (member && !member.roles.cache.has(MUTED_ROLE_ID)) {
            await member.roles.add(MUTED_ROLE_ID, "[Reconciliation] Reapplying active mute");
          }
        } catch {
          // Member may not be in the guild
        }
      }
    }

    console.log(
      `[Punishments] Reconciliation complete: ${activePunishments.length} active punishments checked.`
    );
  } catch (error) {
    console.error("[Punishments] Reconciliation failed:", error);
  }
}
